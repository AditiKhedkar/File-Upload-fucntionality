import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<app-upload></app-upload>'
})
export class AppComponent {}
